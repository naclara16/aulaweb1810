let carros = ["999 - Ferrari 488", "0 - Corsa", "999 - Jetta", "0 -Uno", "0 - Escort" ]

let carrosVelozes = []

carros.forEach(

    /*function selecionarCarros(carro){

    }  outra forma de fazer*/


(carro) => {
    if(carro.startsWith("999")){
        console.log(carro.substring(6) + " foi adicionado para o grupo de carros velozes")
        carrosVelozes.push(carro)
    }
}

)
   