let cantores = ["Taylor swift", "Olivia rodrigo", "Ariana Grande", "Billie Eilish", "Anitta", "Luisa sonza"]

for(let cantor of cantores){

    if(cantor== "Taylor swift" || cantor == "Olivia rodrigo" || cantor == "Billie Eilish"){
        console.log(cantor + " é uma cantora depressiva")
    }else {
        console.log(cantor + " é uma cantora feliz" )
    }
}