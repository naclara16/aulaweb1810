// -------------------------------- MAP ----------------------------
let numeros = [1, 4, 9]

let dobro = numeros.map(

    function(num){
        return num*2
    }
    //(num) => num * 2
)
console.log(dobro)

let numeros2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

let elevado = numeros2.map(
    function(num){
        //return num ** num
        return Math.pow(num, num) 
    }
)
console.log(elevado)

//--------------------------FILTER-------------------

let nomes = ["João", "Marcela", "Ana", "Guilherme", "Melissa", "Bill"]

function nomeGrande(nome){
    return nome.length > 5
}

let nomesGrandes = nomes.filter(nomeGrande)

console.log("Nomes Grandes: " + nomesGrandes)

//-----------------------FIND---------------------------------

let nomeProcurado = nomes.find( (nome) => nome.startsWith ("J") )

console.log("Nomes começados com J: " + nomeProcurado)

let nomesProcurados = nomes.filter( (nome) => nome.startsWith("J") )

console.log("Nomes começados com J: " + nomesProcurados)


//-----------------------FindIndex-----------------------

let encontrarPosicao = nomes.findIndex( (nome) => nome == "Ana")

console.log(encontrarPosicao)


//-------------------------SOME------------------------------

let temAlgum = nomes.some( (nome) => nome == "Melissa")

console.log("Tem alguma Melissa: " + temAlgum)

//--------------------------EVERY--------------------------------

let nomesMaioresQue4Letras = nomes.every(
    (nome) => nome.length > 4

)

console.log("Nomes maiores que 4 letras: " + nomesMaioresQue4Letras)

//-----------------------------FILL---------------------------------

let mudarValores = nomes.fill("Billie Eilish", 4)

console.log(mudarValores)

//--------------------------------